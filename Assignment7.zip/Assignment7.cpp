#include <iostream>
#include "MovieTree.h"
#include <sstream>
#include <fstream>
#include <stdlib.h>
using namespace std;

int main(int argc, char *argv[])
{   string input;
    MovieTree test;
    ifstream inFile;
    string data;
    inFile.open("Assignment6Movies.txt");
    if (inFile.good())
    {
        while((getline(inFile,data)))
        {
            stringstream ss(data);

            string tempranking;
            getline(ss,tempranking,',');
            int in_ranking=atoi(tempranking.c_str());

            string title;
            getline(ss,title,',');
            string in_title=title;

            string tempyear;
            getline(ss,tempyear,',');
            int in_year=atoi(tempyear.c_str());

            string tempquantity;
            getline(ss,tempquantity);
            int in_quantity=atoi(tempquantity.c_str());

            test.addMovieNode(in_ranking, in_title, in_year, in_quantity);

        }
        inFile.close();

    }
    else
    {
        cout<<"file did not open successfully"<<endl;
    }
    string choice;
    while (choice!="6")
    {
        cout << "======Main Menu======" << endl;
        cout << "1. Find a movie" << endl;
        cout << "2. Rent a movie" << endl;
        cout << "3. Print the inventory" << endl;
        cout << "4. Delete a movie" << endl;
        cout << "5. Count the movies" << endl;
        cout << "6. Quit" << endl;
        getline(cin, choice);

        if (choice=="1")
        {   string input;
            cout<<"Enter title:"<<endl;
            getline(cin, input);
            test.findMovie(input);
        }
        if (choice=="2")
        {
            string input;
            cout<<"Enter title:"<<endl;
            getline(cin, input);
            test.rentMovie(input);
        }
        if (choice=="3")
        {

            test.printMovieInventory();
        }
        if (choice=="4"){
                string input;
               cout << "Enter title:" << endl;
                getline(cin,input);
               test.deleteMovieNode(input);


        }
        if (choice=="5"){
              cout<<"Tree contains: "<<test.countMovieNodes()<<" movies."<<endl;
        }

    }
    cout<<"Goodbye!"<<endl;
    return 0;
}
