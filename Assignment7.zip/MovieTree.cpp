#include "MovieTree.h"
#include <sstream>
#include <fstream>
#include <iostream>
#include <string>
using namespace std;
MovieTree::MovieTree()
{
    root = NULL;
}

MovieTree::~MovieTree()
{
    DeleteAll(root);
}

void MovieTree::addMovieNode(int ranking, string title, int releaseYear, int quantity)
{
            MovieNode *node=new MovieNode(ranking,title,releaseYear,quantity);

            MovieNode *tmp=root;

            MovieNode *parent=NULL;

            while(tmp!=NULL)
        {
            parent=tmp;

            if(node->title.compare(tmp->title)<0)
            {

                tmp=tmp->leftChild;

            }
            else
               {

                   tmp=tmp->rightChild;
               }
        }

        if(parent==NULL)
            {
                root=node;
            }
            else if(node->title.compare(parent->title)<0)
            {
                parent->leftChild=node;
                node->parent=parent;

            }
            else
            {
                parent->rightChild=node;
                node->parent=parent;

            }
        }
void MovieTree::findMovie(string input)
{
    MovieNode *node=root;
    while(node!=NULL){
        if(input==node->title){
            cout << "Movie Info:" << endl;
            cout << "===========" << endl;
            cout << "Ranking:" << node->ranking << endl;
            cout << "Title:" << node->title << endl;
            cout << "Year:" << node->year << endl;
            cout << "Quantity:" << node->quantity << endl;
            break;
        }
        else if(input>=node->title){
                node=node->rightChild;
        }
        else{
                node=node->leftChild;
        }

    }
    if(node==NULL)
    {
        cout<<"Movie not found."<<endl;
    }
}
void MovieTree::rentMovie(string input){

    MovieNode *node=root;
    while(node!=NULL){

        if(input==node->title && node->quantity!=0){
          node->quantity--;
            cout << "Movie has been rented." << endl;
            cout << "Movie Info:" << endl;
            cout << "===========" << endl;
            cout << "Ranking:" << node->ranking << endl;
            cout << "Title:" << node->title << endl;
            cout << "Year:" << node->year << endl;
            cout << "Quantity:" << node->quantity << endl;
            break;
            }
        else if (node->quantity==0)
           {
                cout << "Movie out of stock." << endl;
                break;
           }

        else if(input>=node->title){
                node=node->rightChild;
        }
        else{
                node=node->leftChild;
        }
        }
        if(node==NULL)
        {
            cout<<"Movie not found."<<endl;

        }
    if(node!=NULL){
    if(node->quantity==0){

        deleteMovieNode(input);
    }
    }

}
void MovieTree::printMovieInventory(){
    printMovieInventory(root);
}
void MovieTree::printMovieInventory(MovieNode *tmp){
    if(tmp->leftChild!=NULL)
    {
       printMovieInventory(tmp->leftChild);
    }
       cout<<"Movie: "<<tmp->title<<" "<<tmp->quantity<<endl;
    if(tmp->rightChild!=NULL){
       printMovieInventory(tmp->rightChild);
    }

}
void MovieTree::deleteMovieNode(string input){
    MovieNode *tmp=root;
    while(tmp!=NULL){ //find the node
            if(tmp->title==input){
                break;
            }
            else if(input>=tmp->title){
                tmp=tmp->rightChild;
            }
            else{
                tmp=tmp->leftChild;
            }

    }
    if(tmp==NULL)
    {
        cout<<"Movie not found."<<endl;
       }
    else{
            if(tmp->leftChild==NULL && tmp->rightChild==NULL){ //case if node has no children

            if(tmp->parent->leftChild==tmp){
                tmp->parent->leftChild=NULL;
            }
            else{
                tmp->parent->rightChild=NULL;
            }

    }
    else if(tmp->leftChild==NULL && tmp->rightChild!=NULL){ //if
         MovieNode *x=tmp->rightChild;
         if(tmp==tmp->parent->rightChild){
                tmp->parent->rightChild = x;
            }
            if(tmp==tmp->parent->leftChild){
                tmp->parent->leftChild = x;
            }
            x->parent = tmp->parent;
            delete tmp;


    }
     else if(tmp->rightChild==NULL && tmp->leftChild!=NULL){ //if
         MovieNode *x=tmp->leftChild;
         if(tmp==tmp->parent->rightChild){
                tmp->parent->rightChild = x;
            }
            if(tmp==tmp->parent->leftChild){
                tmp->parent->leftChild = x;
            }
            x->parent = tmp->parent;
            delete tmp;

     }
     else if(tmp->rightChild!=NULL && tmp->leftChild!=NULL){
            MovieNode *x=tmp->rightChild;
            while(x->leftChild!=NULL){
                x=x->leftChild;
            }

                 if(tmp != root){

        if(tmp->parent->leftChild == tmp){
            if(x == tmp->rightChild){
                tmp->parent->leftChild = x;
                x->parent = tmp->parent;
                x->leftChild = tmp->leftChild;
            }
            else{
                x->parent->leftChild = x->rightChild;
                x->parent = tmp->parent;
                x->rightChild->parent = x->parent;
                tmp->parent->leftChild = x;
                x->leftChild = tmp->leftChild;
                x->rightChild = tmp->rightChild;
                tmp->rightChild->parent = x;
                tmp->leftChild->parent = x;
            }
        }
        else{
            if(x == tmp->rightChild){
                tmp->parent->rightChild = x;
                x->parent = tmp->parent;
            }
            else{
                x->parent->leftChild = x->rightChild;
                x->parent = tmp->parent;
                x->rightChild->parent = x->parent;
                tmp->parent->rightChild = x;
                x->leftChild = tmp->leftChild;
                x->rightChild = tmp->rightChild;
                tmp->rightChild->parent = x;
                tmp->leftChild->parent = x;
            }


            }
                delete tmp;
            }


        }

        }

     }





int MovieTree::countMovieNodes(){
   countMovieNodes(root);
}

int MovieTree::countMovieNodes(MovieNode *tmp){
    if(tmp==NULL){
        return 0;
    }
    else{
        return countMovieNodes(tmp->leftChild)+countMovieNodes(tmp->rightChild)+1;
    }
}
void MovieTree::DeleteAll(MovieNode *tmp){
    if(tmp->leftChild!=NULL){
        DeleteAll(tmp->leftChild);
    }
    if(tmp->rightChild!=NULL){
        DeleteAll(tmp->rightChild);
    }
    cout<<"Deleting: "<<tmp->title<<endl;
    delete tmp;
}






















